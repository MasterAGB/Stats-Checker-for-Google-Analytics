

document.addEventListener('DOMContentLoaded', function () {
    init_background();
});